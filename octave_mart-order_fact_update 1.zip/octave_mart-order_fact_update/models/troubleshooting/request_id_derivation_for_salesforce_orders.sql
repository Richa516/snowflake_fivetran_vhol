with one as (
  select
    *,
    concat(left (split_part(request_id_fetched_from_lims_requests, '-', 2), 4), '-', right(left(split_part(request_id_fetched_from_lims_requests, '-', 2), 6), 2), '-', right(split_part(request_id_fetched_from_lims_requests, '-', 2), 2)) as effective_date_derived
  from
    {{ ref('fetch_request_id_for_salesforce_order') }}
  where
    ob_lims_request_id_c is null
  order by
    request_id_fetched_from_lims_requests desc
)
select
  *,
  case
    when effective_date = effective_date_derived then "ok"
    else "not ok"
  end as check
from
  one