{{ config(materialized="table")}}

with physicians as (
  select
    distinct trim(lower(firstname)) as firstname,
    trim(lower(lastname)) as lastname,
    npinumber
  from
    hive_metastore.lims.u_physician
),
contacts as (
  select
    distinct trim(lower(first_name)) as first_name,
    trim(lower(last_name)) as last_name,
    ob_npi_c
  from
    hive_metastore.salesforce.contact
),
combined as (
  select
    *
  from
    physicians full
    outer join contacts on physicians.firstname = contacts.first_name
    and physicians.lastname = contacts.last_name
)
select
  firstname,
  lastname,
  npinumber,
  first_name,
  last_name,
  ob_npi_c,
  case
    when ob_npi_c not rlike '^[0-9]{10}$' then npinumber
    else ob_npi_c
  end as npi_new
from
  combined;