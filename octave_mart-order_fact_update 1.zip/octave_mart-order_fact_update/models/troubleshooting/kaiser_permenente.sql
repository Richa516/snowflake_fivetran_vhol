{{ config(materialized="table") }}

with accounts as (
  select
    account_id,
    account_name,
    account_owner_id,
    primary_physician
  from
    {{ ref('stg_salesforce__account') }}
  where
    account_name like "%Kaiser Permanente San Jose%"
),

salesforce__owner_performance as (
  select
    distinct 
      owner_id,
      owner_name
  from
    hive_metastore.salesforce.salesforce__owner_performance
),

contacts (
  select
    distinct 
      contact_id,
      contact_name
  from
    {{ ref('stg_salesforce__contact')}}
)

select
  accounts.*,
  salesforce__owner_performance.*,
  contacts.*
from
  accounts
left join 
  salesforce__owner_performance 
  on accounts.account_owner_id = salesforce__owner_performance.owner_id
left join 
  contacts 
  on accounts.primary_physician = contacts.contact_id