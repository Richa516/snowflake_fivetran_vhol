-- These two trf labels from salesforce do not a requestid even in LIMS -> 'CA1CNNC4', 'CAXBKPEN'
-- The effective dates for the two trf labels are 2022-10-21 and 2022-07-29 respectively

{{ config(materialized = "table") }}

with salesforce_orders as (
  select
    *
  from
    hive_metastore.salesforce.order
),

salesforce_orders_subset_one as (
  select
    id,
    order_number,
    ob_trf_id_c,
    ob_lims_request_id_c,
    ob_test_kit_c
  from
    salesforce_orders
),

date_fields_from_salesforce_orders (
  select
    ob_date_of_service_c,
    effective_date,
    ob_lab_hold_date_c,
    -- end_date,
    -- activated_date,
    ob_processing_start_date_c,
    created_date,
    -- last_modified_date,
    -- system_modstamp,
    -- last_viewed_date,
    -- last_referenced_date,
    ob_lab_hold_release_date_c,
    ob_processing_complete_date_c
  from
    salesforce_orders
),

min_value_of_date_fields as (
  select
    min(ob_date_of_service_c),
    min(effective_date),
    min(ob_lab_hold_date_c),
    min(ob_processing_start_date_c),
    min(created_date),
    min(ob_lab_hold_release_date_c),
    min(ob_processing_complete_date_c)
  from
    date_fields_from_salesforce_orders
),

missing_request_ids as (
  select
    effective_date,
    id,
    order_number,
    ob_trf_id_c,
    ob_lims_request_id_c
  from
    salesforce_orders
  where
    ob_lims_request_id_c is null
  order by
    effective_date desc
)

-- 
select
    effective_date,
    id,
    order_number,
    ob_trf_id_c,
    ob_lims_request_id_c,
    case when ob_lims_request_id_c is null then request_id else ob_lims_request_id_c end as request_id_fetched_from_lims_requests
from
    salesforce_orders
    left join octave_mart_dev.staging.stg_lims__s_request as stg_requests
    on salesforce_orders.ob_trf_id_c = stg_requests.tube_barcode