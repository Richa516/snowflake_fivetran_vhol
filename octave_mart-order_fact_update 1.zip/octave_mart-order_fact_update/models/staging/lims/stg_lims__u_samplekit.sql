-- Dummies are removed based on u_samplekitid
-- Assumption: No dummies have been inserted by Octave for RnD

with rawdata as (
    select
        u_samplekitid as sample_kit_id, -- Primary Key (no nulls observed in this field)
        samplekitdesc as sample_kit_description,
        usersequence as user_sequence,
        auditsequence as audit_sequence,
        tracelogid as tracelog_id,
        templateflag as template_flag,
        notes,
        timestamp(createdt) as created_date,
        createby as created_by,
        createtool as created_tool,
        timestamp(moddt) as modified_date,
        modby as modified_by,
        modtool as modified_tool,
        activeflag as active_flag,
        trackingnumber as tracking_number,
        courier,
        timestamp(receivedate) as received_date,
        samplecondition as sample_condition,
        u_outgoingkitid as outgoing_kit_id,
        d0psbatchid as dops_batch_id,
        timestamp(d0pslastinsorupddate) as dops_last_insert_or_update_date,
        d0pssourcefile as dops_sourcefile,
        d0psupdorins as dops_update_or_insert
    from
        {{ source('lims', 'u_samplekit') }}
    -- where
    --     u_samplekitid rlike "{{ var('standardize__sample_kit_id') }}"
)

select 
    sample_kit_id,
    notes,
    active_flag,
    tracking_number,
    courier,
    outgoing_kit_id,
    created_date,
    received_date,
    modified_date
from 
    rawdata