with rawdata as (
    select
        u_samplescoreid,
        pathwayscoreid,
        usersequence,
        auditsequence,
        tracelogid,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        scorename,
        scorevalue,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'u_pathwayscore') }}
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_samplescoreid', 'moddt') }}
)

select * from deduping