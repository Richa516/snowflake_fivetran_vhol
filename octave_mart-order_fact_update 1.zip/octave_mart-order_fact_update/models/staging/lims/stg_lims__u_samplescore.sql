-- Dummies removed based on ifcbatchid

with rawdata as (
    select
        u_samplescoreid,
        samplescoredesc,
        usersequence,
        auditsequence,
        tracelogid,
        templateflag,
        notes,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        activeflag,
        entrytype,
        timestamp(batchdt),
        source,
        patientid,
        sampleid,
        gender,
        age,
        msrangeversion,
        modelversion,
        dascore,
        timestamp(sampledt),
        plateid,
        ifcbatchid,
        controlid,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'u_samplescore') }}
    -- where
    --     ifcbatchid rlike "{{ var('standardize__ifc_batch') }}"
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_samplescoreid', 'moddt' )}}
)

select * from deduping