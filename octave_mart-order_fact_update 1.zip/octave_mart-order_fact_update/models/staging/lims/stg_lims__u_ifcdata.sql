with rawdata as (
    select
        u_ifcdataid,
        ifcdatadesc,
        usersequence,
        auditsequence,
        tracelogid,
        templateflag,
        notes,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        activeflag,
        ifcsdcid,
        ifckeyid,
        assay,
        sampleindex,
        panelversion,
        npx,
        ctvalue,
        quantvalue,
        normalizationfactor,
        sourcebatchid,
        outsideloq,
        expectedconc,
        calcuatedconc,
        accuracy,
        qcwarningflag,
        assaywarningflag,
        ifcbatchid,
        calculatedconc,
        qcdeviationincctrl,
        qcdeviationdetctrl,
        excludecontrolflag,
        precision,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from
        {{ source('lims', 'u_ifcdata') }}
    -- where
    --     ifcbatchid rlike "{{ var('standardize__ifc_batch') }}"
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_ifcdataid', 'moddt') }}
)

select * from deduping