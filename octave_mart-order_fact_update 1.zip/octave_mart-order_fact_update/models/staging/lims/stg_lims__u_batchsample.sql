-- Dummies removed based on batchid and sampleid

with rawdata as (
    select
        u_batchsampleid,
        batchsampledesc,
        usersequence,
        auditsequence,
        tracelogid,
        templateflag,
        notes,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        activeflag,
        batchid,
        case 
            when sampleid = 'C-AL1QXI8' then '{{ var("CA-L1QXI8") }}'
            when sampleid = 'CA-TVFXAFCA-TVFXAF' then '{{ var("CA-TVFXAF") }}'
            else sampleid 
        end as sampleid,
        sampletype,
        d0psbatchid,
        d0pslastinsorupddate,
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'u_batchsample') }}
    -- where 
    --     (batchid rlike "{{ var('standardize__ifc_batch') }}" 
    --     or batchid rlike "{{ var('standardize__batch') }}")
    --     and (sampleid not rlike {{ var('standardize__sample_id') }}
    --     and sampleid not in {{ var('sampleid__exclude') }})
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_batchsampleid', 'moddt') }}
)

select 
    u_batchsampleid,
    batchsampledesc,
    usersequence,
    auditsequence,
    tracelogid,
    templateflag,
    notes,
    createdt,
    createby,
    createtool,
    moddt,
    modby,
    modtool,
    activeflag,
    batchid,
    sampleid,
    sampletype
from 
    deduping