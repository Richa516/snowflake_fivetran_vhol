-- Dummies are removed based on the NPI number
-- Only authentic providers are assigned an NPI

with rawdata as (
  select
    u_physicianid,
    firstname,
    lastname,
    title,
    npinumber,
    physiciandesc,
    timestamp(createdt) as createdt,
    timestamp(moddt) as moddt,
    'lims' as source
  from
    {{ source('lims', 'u_physician') }}
  where
    npinumber rlike '^[0-9]{10}$'
),

deduping as (
  {{ dedup_dataset('rawdata', 'u_physicianid', 'moddt') }}
)

select * from deduping