with rawdata as (
    select
        u_samplescoreid,
        u_biomarkerscoreid,
        usersequence,
        auditsequence,
        tracelogid,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        biomarker,
        inputvalue,
        concunit,
        concrange,
        adjustedinput,
        errormessage,
        concvalue,
        concpercentile,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'u_biomarkerscore') }}
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_samplescoreid', 'moddt') }}
)

select * from deduping