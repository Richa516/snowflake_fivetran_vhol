-- Dummies removed based on s_subjectid ans u_participantid

with rawdata as (
    select
        s_subjectid,
        subjectdesc,
        subjecttype,
        speciesid,
        strainid,
        birthdt,
        genderflag,
        activeflag,
        usersequence,
        notes,
        auditsequence,
        tracelogid,
        templateflag,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        deathdt,
        mrn,
        cdx_clientid,
        securityuser,
        securitydepartment,
        u_firstname,
        u_lastname,
        u_middleinitial,
        u_addressline1,
        u_addressline2,
        u_city,
        u_state,
        u_zipcode,
        u_ageatdiagnosis,
        u_phone,
        u_email,
        u_prefcomm,
        u_alias,
        u_yrdiagnos,
        u_yrfirstsymp,
        u_height,
        u_weight,
        u_smokingstatus,
        u_ethnicity,
        u_race,
        u_octaveid,
        u_country,
        u_alternateidentifier,
        u_externalparticipantid,
        split_part(u_externalparticipantid, '-', 2) as clinic__address_id,
        u_participantsite,
        u_siteid,
        u_subjectdmt,
        u_participantid,
        u_futureresearchconsent,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 's_subject') }}
    -- where 
    --     s_subjectid rlike "{{ var('standardize__subject_id') }}"
    --     and u_participantid rlike "{{ var('standardize__participant_id') }}"
),

deduping as (
    {{ dedup_dataset('rawdata', 's_subjectid', 'moddt') }}
)

select * from deduping