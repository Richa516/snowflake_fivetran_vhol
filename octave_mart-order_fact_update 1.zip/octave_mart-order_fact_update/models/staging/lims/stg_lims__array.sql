-- Dummies removed based on u_sourcebatchid and arrayid

with rawdata as (
    select 
        arrayid,
        arraytypeid,
        arraytypeversionid,
        arraydesc,
        classification,
        arraystatus,
        usersequence,
        notes,
        auditsequence,
        tracelogid,
        templateflag,
        createdt,
        createby,
        createtool,
        moddt,
        modby,
        modtool,
        activeflag,
        arraylayoutid,
        arraylayoutversionid,
        u_octavestatus,
        u_sourcebatchid,
        u_targetbatchid,
        u_plateorderid,
        u_duedt,
        deliveredrunfileflag,
        d0psbatchid,
        d0pslastinsorupddate,
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'array') }}
    -- where
    --     u_sourcebatchid rlike '{{ var("standardize__source_batchid") }}'
    --     and arrayid rlike '{{ var("standardize__arrayid") }}'
),

deduping as (
    {{ dedup_dataset('rawdata', 'arrayid', 'moddt') }}
)

select * from deduping