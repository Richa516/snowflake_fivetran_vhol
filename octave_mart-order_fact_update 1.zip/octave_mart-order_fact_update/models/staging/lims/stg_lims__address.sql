-- Dummies removed based on u_hconpi

with rawdata as (
    select 
        addressid,
        addresstype,
        addressdesc,
        addressstatus,
        firstname,
        lastname,
        middlename,
        honorificname,
        title,
        address1,
        address2,
        address3,
        city,
        state,
        postalcode,
        country,
        phone,
        fax,
        voicemail,
        cellphone,
        beeper,
        email,
        networkaddress,
        directory,
        printerid,
        tableid,
        notes,
        auditsequence,
        tracelogid,
        templateflag,
        usersequence,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        s_prepaidflag,
        s_partialinvoiceflag,
        s_preferredshiptype,
        activeflag,
        externalflag,
        inv_languageid,
        inv_invoicinggroup,
        securityuser,
        securitydepartment,
        u_hconpi,
        u_eval,
        u_externalsiteid,
        u_externalsiteflag,
        u_invoice,
        d0psbatchid,
        d0pslastinsorupddate,
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'address') }}
    -- where 
    --     u_hconpi rlike "{{ var('standardize__hconpi') }}"
),

deduping as (
    {{ dedup_dataset('rawdata', 'addressid', 'moddt') }}
)

select * from deduping