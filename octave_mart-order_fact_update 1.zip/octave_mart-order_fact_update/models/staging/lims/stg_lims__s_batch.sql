-- Dummies are removed based on the IFC batchid and Normal batchid

-- Batches are of two types
-- 1. Normal batch -> B-(8 numbers)-(2 nos) i.e., B-xxxxxxxx-xx
-- 2. IFC batch -> a series of 10 numbers i.e., xxxxxxxxxx
-- Anything apart from 1 and 2 are dummy/test batches and need to be filtered out

-- Life cycle of a batch (oldest date ---> most recent date)
-- Normal batch, u_octavestatus => Created -> Inc Plate_Day1 -> Inc Plate_Day2 -> Detection Plate -> Pass QC or Fail QC
-- IFC batch, u_octavestatus => Created -> Ready for IFC Load -> IFC QC In Progress -> Pass QC or Fail QC

with rawdata as (
    select
        s_batchid,
        batchdesc,
        timestamp(createdt),
        timestamp(batchdt),
        createby,
        batchstatus,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        notes,
        auditsequence,
        tracelogid,
        usersequence,
        templateflag,
        productid,
        releasedby,
        batchtype,
        batchsize,
        batchsizeunits,
        timestamp(receiveddt),
        receivedby,
        timestamp(releaseddt),
        supplieraddressid,
        timestamp(manufacturedt),
        supplieraddresstype,
        prodvariantlotreference,
        manufactureraddressid,
        manufactureraddresstype,
        levelid,
        disposition,
        prodvariantid,
        productionsiteaddressid,
        productionsiteaddresstype,
        samplingplanid,
        samplingplanversionid,
        activeflag,
        batchmode,
        timestamp(cancelleddt),
        productversionid,
        cancelledby,
        expectedbatchsize,
        expectedbatchsizeunits,
        timestamp(holddt),
        holdby,
        timestamp(expirydt),
        materialid,
        sitedepartmentid,
        u_octavestatus,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 's_batch') }}
    -- where (
    --     s_batchid rlike "{{ var('standardize__ifc_batch') }}" 
    --     or s_batchid rlike "{{ var('standardize__batch') }}"
    --     )
),

deduping as (
    {{ dedup_dataset('rawdata', 's_batchid', 'moddt') }}
)

select * from deduping