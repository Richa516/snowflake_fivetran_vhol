with rawdata as (
    select
        u_ifcctrldataid,
        ifcctrldatadesc,
        usersequence,
        auditsequence,
        tracelogid,
        templateflag,
        notes,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        activeflag,
        ifcdataid,
        ifckeyid,
        assay,
        meanconc,
        percentcv,
        sourcebatchid,
        npxcontrollist,
        excludedcontrollist,
        controlversion,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'u_ifcctrldata') }}
    -- where
    --     sourcebatchid rlike '{{ var("standardize__source_batchid") }}'
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_ifcctrldataid', 'moddt') }}
)

select * from deduping