with rawdata as (
    select 
        u_phyaddressid,
        phyaddressdesc,
        usersequence,
        auditsequence,
        tracelogid,
        templateflag,
        notes,
        timestamp(createdt),
        createby,
        createtool,
        timestamp(moddt),
        modby,
        modtool,
        activeflag,
        physicianid,
        addressid,
        faxnumber,
        addresstype,
        reportdeliverymethod,
        emailid,
        notificationemailid,
        boxfolderid,
        boxsharedlink,
        d0psbatchid,
        timestamp(d0pslastinsorupddate),
        d0pssourcefile,
        d0psupdorins
    from 
        {{ source('lims', 'u_phyaddress') }}
),

deduping as (
    {{ dedup_dataset('rawdata', 'u_phyaddressid', 'moddt') }}
)

select * from deduping