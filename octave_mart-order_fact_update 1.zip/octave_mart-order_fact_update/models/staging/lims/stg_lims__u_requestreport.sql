with rawdata as (
    select 
        u_requestreportid as request_report_id,
        requestreportdesc,
        usersequence,
        auditsequence,
        tracelogid,
        templateflag,
        notes,
        timestamp(createdt) as created_date,
        createby,
        createtool,
        timestamp(moddt) as modified_date,
        modby,
        modtool,
        activeflag,
        requestid as request_id, -- FK to stg_lims__s_request.request_id
        reportstatus as report_status,
        initcap(reporttype) as report_type,
        case 
            when iscanceled = "Y" then true 
            when iscanceled = "N" then false 
        end as is_cancelled,
        reportcontents,
        reporteventid as report_event_id,
        sampleid as sample_id,
        reportdate as report_date,
        reportfilename as report_filename,
        portalresultid as portal_result_id,
        samplescoreid as sample_score_id,
        releasereportuserid as release_report_user_id,
        isreportnotified as is_report_notified,
        d0psbatchid,
        timestamp(d0pslastinsorupddate) as d0pslastinsorupddate,
        d0pssourcefile,
        d0psupdorins
    from
        {{ source('lims', 'u_requestreport') }}
)

select 
    request_report_id,
    request_id,
    report_status,
    report_type,
    is_cancelled,
    report_event_id,
    report_filename,
    portal_result_id,
    sample_score_id,
    release_report_user_id,
    is_report_notified,
    created_date,
    modified_date,
    report_date
from 
    rawdata