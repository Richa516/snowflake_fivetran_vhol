-- Dummies are removed based on the u_outgoingkitid, if any
-- Assumption: No dummies have been inserted by Octave for RnD

-- Lifecycle of a kit = In Salesforce -> Picked up -> Shipped -> On the way -> In transit -> Delivered -> Lost -> Not Found

with rawdata as (
    select
        u_outgoingkitid as outgoing_kit_id,
        outgoingkitdesc as outgoing_kit_description,
        usersequence as user_sequence,
        auditsequence as audit_sequence,
        tracelogid as tracelog_id,
        templateflag as template_flag,
        notes,
        createdt as valid_from,
        createby as created_by,
        createtool as create_tool,
        moddt as modified_date,
        modby as modified_by,
        modtool as modify_tool,
        activeflag as active_flag,
        u_ordernumber as order_number,
        u_clientid as client_id,
        u_shipdt as shipping_date_vendor_to_octave,
        u_shipmethod as shipping_method,
        u_shipcompany as shipping_company,
        u_shipattn as shipping_attention,
        u_addr1 as address_line_1,
        u_addr2 as address_line_2,
        u_addrcity as address_city,
        u_addrstate as address_state,
        u_addrzip as address_zip,
        u_addrouttracknum as address_route_tracking_number,
        u_kititem as kit_item,
        u_kitsn as kit_serial_number,
        u_kitlotnum as kit_lot_number,
        u_kitexpdt as kit_expiry_date,
        u_rettracknum,
        u_tubesn as tube_serial_number,
        case 
            when u_recd = 'Y' then 'Yes'
            when u_recd = "N" then "No"
            else u_recd end as is_received,
        u_2dcode,
        u_samplekitid as sample_kit_id,
        u_tubequantity as tube_qty,
        u_kitstatus as kit_status,
        labeldt as label_date,
        acctnum as account_number,
        securityuser as security_user,
        securitydepartment as security_department,
        estdeliverydate as estimated_delivery_date,
        kitpickupdate as kit_pickup_date,
        d0psbatchid as dops_batch_id,
        d0pslastinsorupddate as dops_last_insert_or_update_date,
        d0pssourcefile as dops_sourcefile,
        d0psupdorins as dops_update_or_insert
    from 
        {{ source('lims', 'u_outgoingkit') }}
),

fetch_latest_records as (
    {{ dedup_dataset('rawdata', 'outgoing_kit_id', 'modified_date') }}
)

select 
    outgoing_kit_id,
    valid_from,
    modified_date,
    active_flag,
    order_number,
    client_id,
    shipping_date_vendor_to_octave, -- like the incoming_date
    shipping_method,
    shipping_company,
    shipping_attention,
    address_line_1,
    address_line_2,
    address_city,
    address_state,
    address_zip,
    address_route_tracking_number,
    kit_item,
    kit_serial_number,
    kit_lot_number,
    kit_expiry_date,
    u_rettracknum,
    tube_serial_number,
    is_received,
    u_2dcode,
    kit_status,
    label_date,
    account_number,
    security_user,
    security_department,
    estimated_delivery_date,
    kit_pickup_date
from 
    fetch_latest_records


-- u_tubesn / u_trfbarcode / u_tubebarcode / any other variations of the TRF label are the same
-- A TRF is assigned by the kit vendor
-- order number is assigned by salesforce
-- request id is assigned by LIMS