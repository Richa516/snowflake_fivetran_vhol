with rawdata as (
    select
        dense_rank() over (order by assay asc, precision_version asc) as precision_id,
        assay,
        acceptable_precision_criteria,
        crtdate,
        upddate,
        defined_marker_precision,
        acceptable_precision_criteria_3xprecision_criteria,
        precision_version,
        d0psBatchID,
        d0psSourceFile,
        d0psUpdOrIns
    from 
        {{ source('laboratory_prod', 'acceptable_precision_limits_final_transformed') }}
)

select
    precision_id,
    assay,
    defined_marker_precision,
    acceptable_precision_criteria,
    acceptable_precision_criteria_3xprecision_criteria,
    precision_version,
    crtdate,
    upddate
from
    rawdata