with rawdata as (
    select
        dense_rank() over (order by marker asc, version asc) as calibrator_id,
        marker,
        version,
        crtdate,
        upddate,
        cal_lot_id,
        cal_lot_exp,
        msda_kit_lot,
        cal_a_min,
        cal_a_avg,
        cal_a_max,
        cal_b_min,
        cal_b_avg,
        cal_b_max,
        cal_c_min,
        cal_c_avg,
        cal_c_max,
        d0psBatchID,
        d0psSourceFile,
        d0psUpdOrIns
    from 
        {{ source('laboratory_prod', 'msda_kit_caibrators_limit_final_transformed') }}
)

select
    dense_rank() over (order by marker asc, version asc) as calibrator_id,
    marker,
    cal_a_min,
    cal_a_avg,
    cal_a_max,
    cal_b_min,
    cal_b_avg,
    cal_b_max,
    cal_c_min,
    cal_c_avg,
    cal_c_max,
    version,
    crtdate,
    upddate,
    cal_lot_id,
    cal_lot_exp,
    msda_kit_lot
from
    rawdata