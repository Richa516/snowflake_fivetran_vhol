with rawdata as (
    select
        timestamp(_createdon) as valid_from,
        _id as practitioner_key,
        timestamp(_lasttimestamp) as last_timestamp,
        _lastupdatedby as last_updated_by,
        _lastupdatedfrom as last_updated_from,
        timestamp(_lastupdatedon) as last_modified_date,
        _operationtype as operation_type,
        active as active,
        address,
        customdata as custom_data,
        d0psbatchid as dops_batch_id,
        timestamp(d0pslastinsorupddate) as dops_last_insert_or_updated_date,
        d0pssourcefile as dops_source_file,
        d0psupdorins as dops_update_or_insert,
        gender,
        name,
        resourcetype as resource_type,
        role,
        specialty,
        telecom,
        _lastupdatedon_updateOrder as last_updated_on_updateOrder,
        d0pslastinsorupddate_updateOrder as dops_last_insert_or_updated_date_updateOrder,
        'corehub_mart' as source
    from 
        {{ source('corehub_mart', 'practitioner') }}
),

first_dedup as (
    {{ dedup_dataset('rawdata', 'practitioner_key', 'dops_last_insert_or_updated_date') }}
),

second_dedup as (
    {{ dedup_dataset('first_dedup', 'practitioner_key', 'last_modified_date') }}
)

select 
    practitioner_key,
    concat(name[0].given, " ", name[0].family) as provider_name, 
    custom_data.npi as npi,
    role.coding.display[0] as title,
    valid_from,
    cast("9999-12-31" as date) as valid_to,
    last_modified_date,
    source
from 
    second_dedup;