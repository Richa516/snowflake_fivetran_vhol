with rawdata as (
    select 
        _createdon,
        _id,
        _lasttimestamp,
        _lastupdatedby,
        _lastupdatedfrom,
        _lastupdatedon,
        _operationtype,
        active,
        address,
        customdata,
        d0psbatchid,
        d0pslastinsorupddate,
        d0pssourcefile,
        d0psupdorins,
        gender,
        name,
        resourcetype,
        role,
        specialty,
        telecom,
        _lastupdatedon_updateOrder,
        d0pslastinsorupddate_updateOrder
    from {{ source('corehub_mart', 'practitioner') }}
    -- where lower(role.coding.code[0]) != 'np'
), 

first_dedup as (
    {{ dedup_dataset('rawdata', '_id', 'd0pslastinsorupddate') }}
),

second_dedup as (
    {{ dedup_dataset('first_dedup', '_id', '_lastupdatedon') }}
)

select 
    _id,
    concat(name[0].given, " ", name[0].family) as provider_name, 
    customdata.npi as npi,
    role.coding.display[0] as title,
    timestamp(_createdon) as created_at,
    timestamp(_lastupdatedon) as lastupdated_at
from 
    second_dedup;