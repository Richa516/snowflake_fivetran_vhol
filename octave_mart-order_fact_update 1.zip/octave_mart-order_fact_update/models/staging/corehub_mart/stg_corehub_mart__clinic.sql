with rawdata as (
    select 
        _id as clinic_id,
        timestamp(_createdon) as valid_from,
        cast("9999-12-31" as timestamp) as valid_to,
        _lasttimestamp as last_timestamp,
        _lastupdatedby as last_updated_by,
        _lastupdatedfrom as last_updated_from,
        timestamp(_lastupdatedon) as last_modified_date,
        _operationtype as operation_type,
        abbreviation,
        active,
        address,
        dmtpreferences as dmt_preferences,
        generalpractitioner as general_practitioner,
        iotproviderpreferences as iot_provider_preferences,
        name as clinic_name,
        npi,
        programtypes as program_types,
        relapsepreferences as relapse_preferences,
        resourcetype as resource_type,
        subtype as sub_type,
        symptompreferences as symptom_preferences,
        telecom,
        timezone,
        type,
        clinicid,
        email,
        firstname,
        lastname,
        mobilephonenumber as mobile_phonenumber,
        role[0] as role,
        workphonenumber as work_phonenumber,
        d0psbatchid as dops_batch_id,
        d0pslastinsorupddate as dops_last_insert_or_update_date,
        d0pssourcefile as dops_sourcefile,
        d0psupdorins as dops_update_or_insert,
        _lastupdatedon_updateOrder,
        d0pslastinsorupddate_updateOrder,
        'corehub_mart' as source
    from 
        {{ source('corehub_mart', 'clinic') }}
    where
        lower(trim(resourcetype)) = "clinic"
),

assert_chronology as (
    select 
        *,
        {{ dbt_utils.generate_surrogate_key(['npi']) }} as npi_id,
        dense_rank() over (partition by clinic_id order by last_modified_date desc) as updateOrder
    from 
        rawdata
)

select 
    clinic_id,
    type,
    firstname,
    lastname,
    sub_type,
    abbreviation,
    active,
    address,
    dmt_preferences,
    general_practitioner,
    iot_provider_preferences,
    clinic_name,
    npi,
    npi_id,
    program_types,
    relapse_preferences,
    resource_type,
    symptom_preferences,
    telecom,
    timezone,
    clinicid,
    email,
    mobile_phonenumber,
    role,
    work_phonenumber,
    dops_sourcefile,
    dops_last_insert_or_update_date,
    source,
    valid_from,
    valid_to,
    last_modified_date,
    updateOrder,
    case when updateOrder = 1 then True else False end as is_current
from 
    assert_chronology