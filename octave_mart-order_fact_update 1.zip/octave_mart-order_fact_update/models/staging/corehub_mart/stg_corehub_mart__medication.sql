WITH parsed_administration_guidelines AS (
    SELECT
        _id,
        explode(administrationguidelines) AS exploded_guidelines,
        _lastupdatedon
    FROM
       {{ source('corehub_mart', 'medicationknowledge') }}
),
detailed_medication_info AS (
    SELECT
        row_number() over (order by (select null)) as medication_dosage_id,
        mk._id as medication_key,
        COALESCE(mk.code.coding[0].code, 'NA') AS medication_code,
        COALESCE(mk.code.coding[0].display, 'NA') AS medication_name,
        COALESCE(mk.doseform.coding[0].display, 'NA') AS dosage_form,
        COALESCE(mk.customdata.isCustomMedication, false) AS is_custom_medication,
        COALESCE(mk.customdata.isStrictAdherence, false) AS is_strict_adherence,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].doseAndRate.dose[0].unit, 'NA') as dosage_unit,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].doseAndRate.dose[0].value, 'NA') as dosage_value,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].method.coding[0].display, 'NA') as dosage_application,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].route.coding[0].display, 'NA') as physicial_application,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].site.coding[0].display[0], 'NA') as body_site_application,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].timing.repeat.frequency, 'NA') as medication_freqency,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].timing.repeat.period, 'NA') as medication_repeat_period,
        COALESCE(ag.exploded_guidelines.dosage[0].dosage[0].timing.repeat.periodUnit, 'NA') as period_unit,
        current_timestamp() as valid_from,
        '9999-12-31' as valid_to,
        true as is_current
    FROM
        {{ source('corehub_mart', 'medicationknowledge') }} mk 
    JOIN
        parsed_administration_guidelines ag ON mk._id = ag._id
)
SELECT * FROM detailed_medication_info