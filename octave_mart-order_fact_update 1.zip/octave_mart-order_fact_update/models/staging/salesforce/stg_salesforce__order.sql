with lims_requests as (
    select tube_barcode, request_id from {{ ref('stg_lims__s_request') }}
),

rawdata as (
    select
        id as order_key,
        owner_id as account_owner_id,
        contract_id,
        account_id,
        pricebook_2_id,
        original_order_id,
        timestamp(effective_date) as effective_date,
        timestamp(end_date) as end_date,
        is_reduction_order,
        status as order_status,
        description as order_description,
        customer_authorized_by_id,
        company_authorized_by_id,
        type as order_type,
        billing_street,
        billing_city,
        billing_state,
        billing_postal_code,
        billing_country,
        billing_latitude,
        billing_longitude,
        billing_geocode_accuracy,
        shipping_street,
        shipping_city,
        shipping_state,
        shipping_postal_code,
        shipping_country,
        shipping_latitude,
        shipping_longitude,
        shipping_geocode_accuracy,
        name,
        timestamp(activated_date) as activated_date,
        activated_by_id,
        status_code,
        order_number,
        total_amount,
        timestamp(created_date) as valid_from,
        created_by_id,
        timestamp(last_modified_date) as last_modified_date,
        last_modified_by_id,
        cast("9999-12-31" as timestamp) as valid_to,
        is_deleted,
        system_modstamp,
        last_viewed_date,
        last_referenced_date,
        ob_hcp_c as health_care_partner,
        ob_processing_complete_date_c as process_completion_date,
        ob_processing_start_date_c as process_start_date,
        ob_product_c,
        case when trim(ob_trf_id_c) = "C-AL1QXI8" then "{{ var('CA-L1QXI8') }}" else trim(ob_trf_id_c) end as trf_id,
        ob_account_owner_c as account_owner,
        ob_related_account_c as related_account,
        ob_lab_hold_date_c as lab_hold_date,
        ob_lab_hold_reason_c as lab_hold_reason,
        ob_lab_hold_release_date_c as lab_hold_release_date,
        ob_date_of_service_c as date_of_service,
        case when ob_lims_request_id_c is null then request_id else ob_lims_request_id_c end as lims_request_id,
        ob_patient_responsibility_c as patient_responsibility,
        ob_test_kit_c as test_kit,
        initcap(ob_report_type_c) as report_type,
        _fivetran_deleted as fivetran_deleted,
        _fivetran_synced as fivetran_synced,
        'salesforce' as source
    from 
        {{ source('salesforce', 'order') }} as sf_orders
    left join
        lims_requests
        on sf_orders.ob_trf_id_c = lims_requests.tube_barcode
    where
        ob_trf_id_c not in ('CAXBKPEN')

        /*         
        "It is not because we did not produce a report for CAXBKPEN.  We received the kit that the original TRF number was in but the clinic did not use the TRF label.
        In LIMS, the report that was issued for that sample is TRF AA000155"  - Maria DeGuzman 
        */
),

deduping_based_on_order_id as (
    {{ dedup_dataset('rawdata', 'order_key', 'last_modified_date' ) }}
),

-- 'R-20240522-00022' has two orders numbers -> 00015285, 0015386.
-- Since order_key is the PK of the table, we dedup using the PK first and request id after

deduping_based_on_request_id as (
    {{ dedup_dataset('deduping_based_on_order_id', 'lims_request_id', 'last_modified_date')}}
)

select 
    order_key,
    order_status,
    order_type,
    order_number,
    lims_request_id, -- FK -> stg_lims__s_request.request_id
    test_kit, -- FL -> stg_salesforce__test_kit.kit_key
    report_type,
    trf_id,
    account_owner_id,
    account_owner,
    account_id, -- FK -> stg_salesforce__account.account_id
    health_care_partner, -- FK -> stg_salesforce__contact.contact_id
    related_account,
    lab_hold_date,
    lab_hold_reason,
    lab_hold_release_date,
    date_of_service,
    process_start_date,
    process_completion_date,
    effective_date,
    valid_from,
    last_modified_date,
    valid_to,
    source
from 
    deduping_based_on_request_id