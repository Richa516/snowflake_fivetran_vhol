with raw_data as (
    select 
        id as territory_id,
        owner_id,
        is_deleted,
        name as territory_state,
        created_date as created_at,
        created_by_id,
        last_modified_date as last_modified_at,
        last_modified_by_id,
        system_modstamp as system_modified_at,
        last_viewed_date as last_viewed_at,
        last_referenced_date as last_referenced_at,
        ob_state_abbreviation_c as state_abbreviation,
        ob_region_c as region,
        _fivetran_deleted as is_fivetran_deleted,
        _fivetran_synced as fivetran_synced_at,
        'salesforce.ob_territory_alignment_c' as source
    from {{ source('salesforce', 'ob_territory_alignment_c') }}
    where is_deleted = false
)

select 
    territory_id,
    owner_id,
    created_by_id,
    last_modified_by_id,
    territory_state,
    state_abbreviation,
    region,
    source,
    is_deleted,
    is_fivetran_deleted,
    created_at,    
    last_modified_at,
    system_modified_at,
    last_viewed_at,
    last_referenced_at,
    fivetran_synced_at
from raw_data