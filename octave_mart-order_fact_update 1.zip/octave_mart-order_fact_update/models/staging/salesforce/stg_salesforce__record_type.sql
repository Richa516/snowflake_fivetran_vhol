with rawdata as (
    select
        id as record_type_id,
        name as record_type_name,
        developer_name as record_developer_name,
        namespace_prefix,
        description as record_description,
        business_process_id,
        sobject_type as record_type,
        is_active,
        created_by_id,
        timestamp(created_date) as valid_from,
        last_modified_by_id,
        timestamp(last_modified_date) as last_modified_date,
        system_modstamp,
        _fivetran_deleted as fivetran_deleted,
        _fivetran_synced as fivetran_synced,
        'salesforce' as source
    from 
        {{ source('salesforce', 'record_type') }}
    -- where
    --     is_active = 1
),

rename_fields as (
    select
        record_type_id,
        record_type_name,
        record_developer_name,
        record_description,
        record_type,
        is_active,
        valid_from,
        last_modified_date,
        cast('9999-12-31' as timestamp) as valid_to,
        source
    from
        rawdata
),

incremental_loading as (
    select
        record_type_id,
        record_type_name,
        record_developer_name,
        record_description,
        record_type,
        is_active,
        valid_from,
        last_modified_date,
        valid_to,
        source,
        dense_rank() over (partition by record_type_id order by last_modified_date desc) as updateOrder
    from
        rename_fields
)

select 
    record_type_id,
    record_type_name,
    record_developer_name,
    record_description,
    record_type,
    is_active,
    valid_from,
    last_modified_date,
    valid_to,
    source,
    updateOrder,
    case when updateOrder = 1 then True else False end as is_current
from
    incremental_loading