with rawdata as (
    select
        id as contact_id,
        account_id,
        salutation,
        name as contact_name,
        suffix,
        title,
        ob_npi_c as npi,
        record_type_id as contact_type_id,
        department,
        lead_source,
        owner_id as account_owner_id,
        timestamp(created_date) as created_date,
        timestamp(last_modified_date) as last_modified_date,
        named_struct(
            'mailing_street', mailing_street,
            'mailing_city', mailing_city,
            'mailing_state', mailing_state,
            'mailing_postal_code', mailing_postal_code,
            'mailing_country', mailing_country,
            'mailing_latitude', mailing_latitude,
            'mailing_longitude', mailing_longitude,
            'mailing_geocode_accuracy', mailing_geocode_accuracy
        ) as contact_mailing_details,
        named_struct(
            'phone', phone,
            'fax', fax,
            'mobile_phone', mobile_phone,
            'home_phone', home_phone,
            'other_phone', other_phone,
            'email', email
        ) as contact_communication_details,
        named_struct(
            'business_unit', ob_business_unit_c,
            'clinical_focus', string(ob_clinical_focus_c),
            'other_email', ob_other_email_c,
            'linkedin_url', ob_linked_in_url_c,
            'kol', string(ob_kol_c),
            'level_of_adoption', ob_level_of_adoption_c,
            'level_of_advocacy', ob_level_of_advocacy_c,
            'octave_platform_expertise', ob_octave_platform_expertise_c,
            'octave_relationship_score', ob_octave_relationship_score_c,
            'other_speciality', ob_other_specialty_c,
            'patient_count', string(ob_patient_count_c),
            'speciality', ob_specialty_c,
            'title', ob_title_c,
            'cda_signed_date', string(ob_cda_signed_date_c),
            'cda_signed', string(ob_cda_signed_c),
            'last_meeting', string(ob_last_meeting_date_c),
            'lab_orders', ob_lab_orders_c,
            'lims_contact_id', ob_lims_contact_id_c
        ) as contact_aggregations,
        'salesforce' as source
    from 
        {{ source('salesforce', 'contact') }}
    where
        is_deleted = false
),

incremental_loading as (
    select 
        contact_id,
        account_id,
        salutation,
        contact_name,
        suffix,
        title,
        npi,
        contact_type_id,
        department,
        lead_source,
        account_owner_id,
        created_date as valid_from,
        last_modified_date,
        cast("9999-12-31" as date) as valid_to,
        contact_mailing_details,
        contact_communication_details,
        contact_aggregations,
        source,
        dense_rank() over (partition by contact_id order by last_modified_date desc) as updateOrder
    from 
        rawdata
)

select
    contact_id,
    account_id,
    salutation,
    contact_name,
    suffix,
    title,
    npi,
    contact_type_id,
    department,
    lead_source,
    account_owner_id,
    contact_mailing_details,
    contact_communication_details,
    contact_aggregations,
    valid_from,
    last_modified_date,
    valid_to,
    source,
    updateOrder,
    case when updateOrder = 1 then True else False end as is_current
from
    incremental_loading