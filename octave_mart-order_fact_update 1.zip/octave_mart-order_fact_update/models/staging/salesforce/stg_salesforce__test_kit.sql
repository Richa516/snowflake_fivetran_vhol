with one as (
    select
        dense_rank() over (order by created_date asc, ob_kit_serial_number_c asc, name asc) as test_kit_id,
        id as test_kit_key,
        is_deleted,
        name as test_kit_name,
        timestamp(created_date) as valid_from,
        created_by_id,
        timestamp(last_modified_date) as last_modified_date,
        last_modified_by_id,
        system_modstamp,
        timestamp(last_activity_date) as last_activity_date,
        ob_account_c as account,
        ob_kit_serial_number_c as test_kit_serial_number,
        ob_product_c as product,
        ob_return_tracking_number_c as return_tracking_number,
        ob_shipped_date_c as shipped_date,
        ob_trf_id_c as trf_id,
        ob_tube_expiration_date_c as tube_expiration_date,
        ob_status_c as status,
        ob_fulfillment_date_c as fulfillment_date,
        _fivetran_deleted as fivetran_deleted,
        _fivetran_synced as fivetran_synced
    from
        {{ source('salesforce', 'ob_test_kit_c') }}
)

select
    test_kit_id,
    test_kit_key,
    product,
    test_kit_serial_number,
    trf_id,
    test_kit_name,
    shipped_date,
    tube_expiration_date,
    return_tracking_number,
    fulfillment_date,
    status,
    account,
    is_deleted,
    valid_from,
    last_modified_date
from
    one