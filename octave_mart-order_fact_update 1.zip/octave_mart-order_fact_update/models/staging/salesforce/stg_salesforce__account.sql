with rawdata as (
    select
        id as account_id,
        name as account_name,
        timestamp(created_date) as created_date,
        timestamp(last_modified_date) as last_modified_date,
        record_type_id as account_type_id,
        owner_id as account_owner_id,
        account_source,
        ob_partner_status_c as partner_status,
        ob_physician_practice_type_c as physician_practice_type,
        ob_prior_authorization_contact_c as prior_authorization_contact,
        ob_primary_physician_c as primary_physician,
        ob_is_parent_c as is_parent,
        ob_lims_account_id_c as lims_account_id,
        named_struct(
            'billing_street', billing_street,
            'billing_city', billing_city,
            'billing_state', billing_state,
            'billing_postal_code', billing_postal_code,
            'billing_country', billing_country,
            'billing_latitude', billing_latitude,
            'billing_longitude', billing_longitude,
            'billing_geocode_accuracy', billing_geocode_accuracy
        ) as account_billing_details,
        named_struct(
            'shipping_street', shipping_street,
            'shipping_city', shipping_city,
            'shipping_state', shipping_state,
            'shipping_postal_code', shipping_postal_code,
            'shipping_country', shipping_country,
            'shipping_latitude', shipping_latitude,
            'shipping_longitude', shipping_longitude,
            'shipping_geocode_accuracy',shipping_geocode_accuracy
        ) as account_shipping_details,
        named_struct('phone', phone, 'website', website) as account_communication_details,
        named_struct(
            'number_of_employees', number_of_employees,
            'commercial_members', ob_commercial_members_c,
            'medicaid_members', ob_medicaid_members_c,
            'medical_liasion', ob_medical_science_liaison_c,
            'medicare_members', ob_medicare_members_c,
            'pricing_model', ob_pricing_model_c,
            'partnership_established', ob_partnership_established_date_c,
            'last_meeting', ob_last_meeting_date_c,
            'first_lab_order', ob_first_lab_order_date_c,
            'last_clinical_report_review', ob_last_clinical_report_review_date_c,
            'last_order', ob_last_order_date_c,
            'clinicians_at_facility', ob_clinicians_at_facility_c,
            'prescribing_clinicians', ob_prescribing_clinicians_c,
            'patients_at_facility', ob_patients_at_facility_c,
            'active_patients', ob_active_patients_c,
            'ms_patients_at_facility', ob_ms_patients_at_facility_c,
            'ms_patients_seen_per_day', ob_ms_patients_seen_per_day_c,
            'neurologists', ob_neuroradiologists_c,
            'radiologists', ob_radiologists_c,
            'referring_neurologists', ob_referring_neurologists_c,
            'lab_orders', ob_lab_orders_c,
            'last_mri', ob_last_mri_order_date_c,
            'mri_orders', ob_mri_orders_c,
            'canceled_lab_orders', ob_canceled_lab_orders_c,
            'mri_scanner', ob_mri_scanner_c,
            'mri_scans', ob_ms_scans_per_month_c
        ) as account_aggregations,
        'salesforce' as source

    from 
        {{ source('salesforce', 'account') }}
    where
        is_deleted = false
    
),

incremental_loading as (
    select
        account_id,
        created_date as valid_from,
        last_modified_date,
        cast("9999-12-31" as timestamp) as valid_to,
        account_name,
        account_type_id,
        account_owner_id,
        account_source,
        partner_status,
        primary_physician,
        physician_practice_type,
        prior_authorization_contact,
        is_parent,
        lims_account_id,
        account_billing_details,
        account_shipping_details,
        account_communication_details,
        account_aggregations,
        source,
        dense_rank() over (partition by account_id order by last_modified_date desc) as updateOrder
    from 
        rawdata
)

select 
    account_id,
    account_name,
    account_type_id,
    account_owner_id,
    account_source,
    partner_status,
    primary_physician,
    physician_practice_type,
    prior_authorization_contact,
    is_parent,
    lims_account_id,
    account_billing_details,
    account_shipping_details,
    account_communication_details,
    account_aggregations,
    valid_from,
    last_modified_date,
    valid_to,
    source,
    updateOrder,
    case when updateOrder = 1 then True else False end as is_current
from 
    incremental_loading