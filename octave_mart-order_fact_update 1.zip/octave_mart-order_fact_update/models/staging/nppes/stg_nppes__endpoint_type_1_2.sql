-- This file contains all Endpoints associated with Type 1 and Type 2 NPIs.

{{ config(materialized = "view") }}

select
    `NPI` as npi ,
    `Endpoint Type` as endpoint_type ,
    `Endpoint Type Description` as endpoint_type_description ,
    `Endpoint` as endpoint ,
    `Affiliation` as affiliation ,
    `Endpoint Description` as endpoint_description ,
    `Affiliation Legal Business Name` as affiliation_legal_business_name ,
    `Use Code` as use_code ,
    `Use Description` as use_description ,
    `Other Use Description` as other_use_description ,
    `Content Type` as content_type ,
    `Content Description` as content_description ,
    `Other Content Description` as other_content_description ,
    `Affiliation Address Line One` as affiliation_address_line_one ,
    `Affiliation Address Line Two` as affiliation_address_line_two ,
    `Affiliation Address City` as affiliation_address_city ,
    `Affiliation Address State` as affiliation_address_state ,
    `Affiliation Address Country` as affiliation_address_country ,
    `Affiliation Address Postal Code` as affiliation_address_postal_code ,
    `_rescued_data` as _rescued_data
from
    {{ source('reference_data','endpoint_pfile_20050523_20240512') }}