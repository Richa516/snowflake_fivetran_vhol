-- This file contains additional Other Names associated with Type 2 NPIs.

{{ config(materialized = "view") }}

select
    `NPI` as npi ,
    `Provider Other Organization Name` as provider_other_organization_name ,
    `Provider Other Organization Name Type Code` as provider_other_organization_name_type_code ,
    `_rescued_data` as _rescued_data
from
    {{ source('reference_data', 'othername_pfile_20050523_20240512') }}