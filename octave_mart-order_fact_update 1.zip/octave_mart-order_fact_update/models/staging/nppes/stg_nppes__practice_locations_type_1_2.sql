-- This file contains all of the non-primary Practice Locations associated with Type 1 and Type 2 NPIs

{{ config(materialized = "view") }}

select
    `NPI` as npi ,
    `Provider Secondary Practice Location Address- Address Line 1` as provider_secondary_practice_location_address__address_line_1 ,
    `Provider Secondary Practice Location Address-  Address Line 2` as provider_secondary_practice_location_address___address_line_2 ,
    `Provider Secondary Practice Location Address - City Name` as provider_secondary_practice_location_address___city_name ,
    `Provider Secondary Practice Location Address - State Name` as provider_secondary_practice_location_address___state_name ,
    `Provider Secondary Practice Location Address - Postal Code` as provider_secondary_practice_location_address___postal_code ,
    `Provider Secondary Practice Location Address - Country Code (If outside U.S.)` as provider_secondary_practice_location_address___country_code__if_outside_us_ ,
    `Provider Secondary Practice Location Address - Telephone Number` as provider_secondary_practice_location_address___telephone_number ,
    `Provider Secondary Practice Location Address - Telephone Extension` as provider_secondary_practice_location_address___telephone_extension ,
    `Provider Practice Location Address - Fax Number` as provider_practice_location_address___fax_number ,
    `_rescued_data` as _rescued_data
from
    {{ source('reference_data', 'pl_pfile_20050523_20240512') }}