{% docs lims %}

Schema with data from the LIMS (Laboratory Information Management System) System
Labvantage in Databricks

{% enddocs %}