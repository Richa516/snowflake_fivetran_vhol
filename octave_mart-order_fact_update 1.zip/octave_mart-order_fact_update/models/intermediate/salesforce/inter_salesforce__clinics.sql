-- We are joining three tables together
-- Since, this dimension is about clinics, we consider salesforce.account as the driver dataset
-- Therefore, we consider account_created_date 

with accounts as (
    select
        account_id,
        account_name,
        account_type_id,
        account_owner_id,
        primary_physician,
        physician_practice_type,
        valid_from,
        valid_to,
        last_modified_date,
        source,
        updateOrder,
        is_current
    from
        {{ref('stg_salesforce__account') }}
    where 
        primary_physician is not null
),

contacts as (
    select
        contact_id,
        contact_name,
        npi,
        account_id,
        account_owner_id,
        contact_type_id,
        valid_from,
        valid_to,
        last_modified_date,
        source,
        updateOrder,
        is_current
    from
        {{ ref('stg_salesforce__contact') }}
),

record_types as (
    select
        record_type_id,
        record_type_name,
        record_developer_name,
        record_description,
        record_type,
        valid_from,
        valid_to,
        last_modified_date,
        source,
        updateOrder,
        is_current
    from 
        {{ ref('stg_salesforce__record_type') }}
),

accounts_contacts_and_record_types as (
    select
        accounts.account_id,
        accounts.account_name,
        accounts.account_type_id,
        accounts.account_owner_id,
        accounts.primary_physician,
        accounts.physician_practice_type as account_type,
        accounts.source,
        accounts.valid_from as account__valid_from,
        accounts.valid_to as account__valid_to,
        accounts.last_modified_date as account_last_modified_date,
        accounts.updateOrder,
        accounts.is_current,

        contacts.contact_id,
        contacts.contact_name,
        contacts.npi,
        contacts.contact_type_id,
        -- contacts.source_contact,
        contacts.valid_from as contact__valid_from,
        contacts.valid_to as contact__valid_to,
        contacts.last_modified_date as contact_last_modified_date,

        record_types.record_type_id,
        record_types.record_type_name,
        record_types.record_developer_name,
        -- record_types.source_record_type,
        record_types.valid_from as record_type__valid_from,
        record_types.valid_to as record_type__valid_to,
        record_types.last_modified_date as record_type_last_modified_date

    from
        accounts 
    
    left join
        record_types
        on accounts.account_type_id = record_types.record_type_id
        
    left join 
        contacts 
        on accounts.primary_physician = contacts.contact_id
    
    where
        record_types.record_developer_name = "OB_Physician_Practice"
),

surrogate_keygen as (
    select
        {{ dbt_utils.generate_surrogate_key(['npi']) }} as npi_id,
        account_id,
        account_name,
        account_type_id,
        account_owner_id,
        primary_physician,
        account_type,
        source,
        -- source_account,
        account__valid_from,
        account__valid_to,
        account_last_modified_date,
        updateOrder,
        is_current,

        contact_id,
        contact_name,
        npi,
        contact_type_id,
        -- source_contact,
        contact__valid_from,
        contact__valid_to,
        contact_last_modified_date,

        record_type_id,
        record_type_name,
        -- source_record_type,
        record_type__valid_from,
        record_type__valid_to,
        record_type_last_modified_date
    from
        accounts_contacts_and_record_types
)

select
    npi_id,
    account_id,
    account_type,
    account_name,
    account_owner_id,
    npi,
    primary_physician,
    contact_id,
    contact_name,
    source,
    account__valid_from,
    account_last_modified_date,
    account__valid_to,
    updateOrder,
    is_current
from 
    surrogate_keygen