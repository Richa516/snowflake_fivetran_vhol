with indexing as (
    select
        distinct -- (id, developer_name) -> (012Qr000001AQofIAG, OB_Patient_Inquiry) has duplicates (3). Therefore, "DISTINCT"
        dense_rank() over (order by valid_from, record_developer_name asc) as account_category_id,
        -- row_number() over (order by (select null)) as account_category_id,
        record_type_id as account_category_key,
        record_type_name as account_category_name,
        record_developer_name as account_category_developer_name,
        record_description as account_category_description,
        record_type as account_type,
        is_active,
        valid_from,
        last_modified_date,
        valid_to,
        source
    from 
        {{ ref('stg_salesforce__record_type') }}
)

select
    account_category_id,
    account_category_key,
    account_category_name,
    account_category_developer_name,
    account_category_description,
    account_type,
    is_active,
    source,
    valid_from,
    last_modified_date,
    valid_to
from
    indexing