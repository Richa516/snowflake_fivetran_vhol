with stg_lims__s_request as (
    select 
        *,
        date(created_date) as date__created_date,
        concat(extract('HOURS' , created_date), ':', extract('MINS', created_date), ':', extract('SECONDS', created_date)) as time__created_date
    from 
        {{ ref('stg_lims__s_request') }}
),

date_dim as (
    select date from {{ ref('date_dim') }}
)

select * from date_dim
left join stg_lims__s_request
on date_dim.date = stg_lims__s_request.date__created_date