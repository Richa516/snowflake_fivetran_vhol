with rawdata as (
    select 
        shipping_date_vendor_to_octave,
        kit_pickup_date,
        shipping_method,
        shipping_company,
        outgoing_kit_id,
        kit_expiry_date,
        order_number,
        kit_serial_number,
        kit_item,
        kit_lot_number,
        kit_status,
        valid_from,
        date(valid_from) as date__valid_from,
        concat(extract('HOURS' , valid_from), ':', extract('MINS', valid_from), ':', extract('SECONDS', valid_from)) as time__valid_from,
        modified_date,
        date(modified_date) as date__modified_date,
        concat(extract('HOURS' , modified_date), ':', extract('MINS', modified_date), ':', extract('SECONDS', modified_date)) as time__modified_date
    from 
        {{ ref('stg_lims__u_outgoingkit') }}
),

date_dim as (
    select date from {{ ref('date_dim') }}
)

select * from date_dim
left join rawdata
on date_dim.date = rawdata.date__valid_from