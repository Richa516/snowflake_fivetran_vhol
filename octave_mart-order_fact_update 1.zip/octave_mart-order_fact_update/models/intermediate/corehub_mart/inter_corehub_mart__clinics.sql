with rawdata as (
    select
        npi_id,
        clinic_id,
        clinicid,
        replace(trim(split_part(clinic_name, '-', 1)), "RMMSC", "Rocky Mountain MS Center") as clinic_name,
        npi,
        valid_from,
        valid_to,
        last_modified_date,
        address,
        general_practitioner,
        iot_provider_preferences,
        program_types,
        resource_type,
        telecom,
        timezone,
        type,
        email,
        concat(firstname, ' ', lastname) as clinician,
        mobile_phonenumber,
        role,
        work_phonenumber,
        source,
        updateOrder,
        is_current
    from
        {{ ref('stg_corehub_mart__clinic') }}
    where
        lower(resource_type) = "clinic"
)

select
    npi_id,
    clinic_id,
    clinicid,
    clinic_name,
    npi,
    address,
    general_practitioner,
    iot_provider_preferences,
    program_types,
    resource_type,
    telecom,
    timezone,
    type,
    email,
    clinician,
    mobile_phonenumber,
    role,
    work_phonenumber,
    source,
    valid_from,
    valid_to,
    last_modified_date,
    updateOrder,
    is_current
from 
    rawdata