{{
    config(
        materialized = 'incremental'
    )
}}

with lims_physicians as (
    select 
        u_physicianid as _id,
        initcap(concat(firstname, " ", lastname)) as provider_name,
        case 
            when title = 'NP' then 'Nurse Practitioner'
            else title
        end as title,
        npinumber as npi,
        'lims' as source,
        createdt as created_at,
        moddt as modified_at
    from {{ ref('stg_lims__u_physician') }}
    -- where lower(firstname) not like '%dummy%' 
    --     and lower(firstname) not like '%test%'
),

corehub_mart_practitioners as (
    select 
        _id,
        provider_name,
        title,
        npi,
        'corehub_mart' as source,
        created_at,
        lastupdated_at
    from {{ ref('stg_corehub_mart__practitioners') }}
),

salesforce_contacts as (
    select 
        contact_id as id,
        initcap(
            trim(
                split_part(
                    split_part(
                        left(contact_name, 
                            case when len(contact_name) - len(suffix) > 0 then len(contact_name) - len(suffix) 
                                else len(contact_name)
                            end
                        ),"?",1
                    ), ",", 1)
                )
            )  as provider_name,
        case 
            when coalesce(title, contact_aggregations.title) = 'NP'
                then 'Nurse Practitioner'
            else coalesce(title, contact_aggregations.title)
        end as title,
        npi,
        'salesforce' as source,
        valid_from as created_at,
        last_modified_date as last_modified_at
    from {{ ref('stg_salesforce__contact') }}
    where npi is not null
    -- 640 records dont have NPIs
    -- can we create a seed file for them?
    -- have to standardize title once those 640 records added
),

-- NPI for few of the providers are not having 10 digits
-- csv seed added with their name and NPI

seed_provider as(
    select *
    from {{ ref('seed_providers') }}
),

salesforce_correct_npis as (
    select *
    from salesforce_contacts
    where npi rlike '^[0-9]{10}$'
),

salesforce_incorrect_npis as (
    select *
    from salesforce_contacts
    where npi not rlike '^[0-9]{10}$'
),

salesforce_corrected_npis as (
    select 
        salesforce_incorrect_npis.id,
        salesforce_incorrect_npis.provider_name,
        salesforce_incorrect_npis.title,
        seed_provider.npi,
        salesforce_incorrect_npis.source,
        salesforce_incorrect_npis.created_at,
        salesforce_incorrect_npis.last_modified_at
    from salesforce_incorrect_npis
    left join seed_provider
        on salesforce_incorrect_npis.provider_name = seed_provider.physician_name
),

salesforce_combined_records as (
    select *
    from salesforce_correct_npis 

    union all
    
    select *
    from salesforce_corrected_npis
    where npi not in (
        select npi
        from salesforce_correct_npis
    )
),

lims_correct_npis as(
    select *
    from lims_physicians
    where npi rlike '^[0-9]{10}$'
),

lims_incorrect_npis as(
    select *
    from lims_physicians
    where npi not rlike '^[0-9]{10}$'
),

lims_corrected_npis as (
    select
        lims_incorrect_npis._id,
        lims_incorrect_npis.provider_name,
        lims_incorrect_npis.title,
        seed_provider.npi,
        lims_incorrect_npis.source,
        lims_incorrect_npis.created_at,
        lims_incorrect_npis.modified_at
    from lims_incorrect_npis
    left join seed_provider
        on lims_incorrect_npis.provider_name = seed_provider.physician_name
),

lims_corehub_mart_combined_records as (
    select *
    from lims_correct_npis

    union all

    select *
    from lims_corrected_npis

    union all

    select *
    from corehub_mart_practitioners
),

providers_records as (
    select *
    from salesforce_combined_records

    union all

    select *
    from lims_corehub_mart_combined_records
    where npi not in (
        select npi 
        from salesforce_combined_records
    )
),

nurse_care_partners as (
    select
        {{ dbt_utils.generate_surrogate_key(['provider_name', 'npi']) }} as id,
        provider_name,
        title,
        npi,
        source,
        current_timestamp() as created_at,
        current_timestamp() as last_modified_at
    from {{ ref('nurse_care_partners') }}
),

providers_with_nurse_care_partners as (
    select *
    from providers_records
    
    union all
    
    select *
    from nurse_care_partners
),

handling_nulls as (
    select 
        row_number() over (order by (select null))  as provider_id,
        ifnull(id, 'N/A') as provider_key,
        ifnull(provider_name, 'Not Answered') as provider_name,
        ifnull(title,'Not Answered') as title,
        ifnull(npi,'Not Answered') as npi,
        case when source = 'Nurse Care Seed File' then true else false end as is_nurse_care_partner,
        source,
        ifnull(created_at, last_modified_at) as valid_from,
        last_modified_at,
        cast('9999-12-31' as timestamp) as valid_to
    from providers_with_nurse_care_partners
    order by created_at, npi
)

select * from handling_nulls


{% if is_incremental() %}
    where npi not in (select npi from {{this}})
{% endif %}

order by valid_from, npi