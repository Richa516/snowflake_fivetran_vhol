with report_types as (
    select distinct report_type from {{ ref('stg_lims__u_requestreport') }}
)
select 
    -- dense_rank() over (order by report_type asc) as report_type_id,
    row_number() over (order by (select null)) as report_type_id,
    ifnull(report_type, 'N/A') as report_type
from 
    report_types 