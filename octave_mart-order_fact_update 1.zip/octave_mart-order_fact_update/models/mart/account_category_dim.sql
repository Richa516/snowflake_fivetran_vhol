{{ config(materialized = "incremental") }}

select
    account_category_id,
    account_category_key,
    account_category_developer_name,
    account_category_name,
    ifnull(account_category_description, 'N/A') as account_category_description,
    account_type,
    valid_from,
    last_modified_date,
    valid_to
from 
    {{ ref('inter_salesforce__account_category') }}

{% if is_incremental() %}
    where account_category_key not in (select account_category_key from {{this}})
{% endif %}