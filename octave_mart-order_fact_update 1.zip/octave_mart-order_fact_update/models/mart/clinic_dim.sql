{{ config(materialized = "incremental") }}

with salesforce__clinics as (
    select
        npi_id,
        account_id as clinic_id,
        lower(account_type) as clinic_type,
        account_name as clinic_name,
        account_owner_id as account_owner,
        primary_physician as clinician,
        account__valid_from as valid_from,
        account_last_modified_date as last_modified,
        account__valid_to as valid_to,
        npi,
        source,
        updateOrder,
        is_current
    from 
        {{ ref('inter_salesforce__clinics') }}
),

corehub_mart__clinics as (
    select 
        npi_id,
        clinic_id,
        lower(type) as clinic_type,
        clinic_name,
        replace('null', null) as account_owner,
        clinician,
        valid_from,
        last_modified_date as last_modified,
        valid_to,
        npi,
        source,
        updateOrder,
        is_current
    from 
        {{ ref('inter_corehub_mart__clinics') }}
),

combined as (
    select * from salesforce__clinics
    union all
    select * from corehub_mart__clinics
),

handling_nulls as (
    select
        ifnull(clinic_id, 'N/A') as clinic_key,
        ifnull(clinic_type, 'N/A') as clinic_type,
        ifnull(clinic_name, 'N/A') as clinic_name,
        ifnull(account_owner, 'N/A') as account_owner,
        ifnull(clinician, 'N/A') as clinician,
        ifnull(npi, 'N/A') as npi,
        ifnull(valid_from, 'N/A') as valid_from,
        last_modified,
        valid_to,
        source,
        updateOrder,
        is_current
    from
        combined
),

generate_clinic_id as (
    select
        dense_rank() over (order by valid_from asc, clinic_name asc) as clinic_id,
        -- row_number() over (order by (select null)) as clinic_id,
        clinic_key,
        case when clinic_type = "clinical-trial" then 'clinical' else clinic_type end as clinic_type,
        clinic_name,
        valid_from,
        last_modified,
        valid_to,
        source,
        is_current
    from 
        handling_nulls
)

select * from generate_clinic_id

{% if is_incremental() %}
    where clinic_key not in (select clinic_key from {{this}})
{% endif %}