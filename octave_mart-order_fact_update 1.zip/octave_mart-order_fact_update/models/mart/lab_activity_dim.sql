select 
    lab_activity_id,
    lab_activity_type,
    activity_description
from {{ ref('seed_lab_activities') }}