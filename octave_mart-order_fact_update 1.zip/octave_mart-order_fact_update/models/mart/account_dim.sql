select 
    dense_rank() over (order by valid_from asc, account_name asc) as account_id,
    -- row_number() over (order by (select null)) as account_id,
    account_id as account_key,
    account_name,
    -- account_type_id,
    -- account_owner_id,
    ifnull(account_source, 'N/A') as account_source,
    ifnull(partner_status, 'N/A') as partner_status,
    -- primary_physician,
    -- physician_practice_type,
    -- prior_authorization_contact,
    -- is_parent,
    -- lims_account_id,
    -- account_billing_details,
    -- account_shipping_details,
    -- account_communication_details,
    -- account_aggregations,
    valid_from,
    last_modified_date,
    valid_to,
    source
    -- updateOrder,
    -- case when updateOrder = 1 then True else False end as is_current
from 
    {{ ref('stg_salesforce__account') }}