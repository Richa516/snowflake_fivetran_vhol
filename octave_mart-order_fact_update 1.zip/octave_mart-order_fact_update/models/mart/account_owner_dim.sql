with salesforce_accounts as (
    select
        distinct
        account_owner_id as account_owner_key,
        source
    from 
        {{ ref('stg_salesforce__account') }}
),

salesforce_users as (
    select 
        id as user_id, 
        name as account_owner_name
    from 
        {{ source('salesforce', 'user') }}
),

salesforce__orders as (
    select 
        account_owner_id,
        account_owner,
        account_id
    from 
        {{ ref('stg_salesforce__order') }}
),

salesforce__accounts_and_owners as (
    select 
        account_owner_key,
        account_owner_name,
        source
    from salesforce_accounts
    left join salesforce_users
    on salesforce_accounts.account_owner_key = salesforce_users.user_id
),

corehub_mart_account_owners as (
    select * from {{ ref('stg_corehub_mart__clinic') }}
)

select 
    dense_rank() over (order by account_owner_name asc) as account_owner_id,
    -- row_number() over (order by (select null)) as account_owner_id,
    account_owner_key,
    account_owner_name,
    case 
        when source like '%corehub_mart%' then 'corehub_mart' 
        when source like '%salesforce%' then 'salesforce' 
    else source end as source
from 
    salesforce__accounts_and_owners
where
    account_owner_key in (select distinct account_owner_id from salesforce__orders)