with raw_data as (
    select 'Commercial MSDA' as category, 'Commercial support' as sub_category, 'Active' as current_status
    union all
    select 'Commercial MSDA', 'Revenue Ops', 'Active'
    union all
    select 'Pharma', 'MSDA', 'N/A'
    union all
    select 'Pharma', '21 panel', 'N/A'
    union all
    select 'Pharma', 'Explore 48', 'N/A'
    union all
    select 'Pharma', '3-5k Olink studies', 'N/A'
    union all
    select 'MRI', 'Standard analysis', 'Active'
    union all
    select 'MRI', 'Advanced analysis', 'N/A'
    union all
    select 'CI', 'App', 'N/A'
    union all
    select 'CI', 'PROs', 'N/A'
    union all
    select 'CI', 'Nurse', 'N/A'
    union all
    select 'Others', 'Data Science analysis publication', 'N/A'
    union all
    select 'Others', 'Study coordinarion', 'N/A'
    union all
    select 'VBC', 'N/A', 'Future'
    union all
    select 'Parkinsons', 'N/A', 'Active'
    union all
    select 'Pharma', 'Pharma studies', 'Active'
)

select 
    row_number() over (order by (select null)) as service_id,
    category,
    sub_category,
    current_status
from 
    raw_data