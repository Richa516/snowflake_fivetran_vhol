{{ config(materialized = "incremental") }}

select 
    row_number() over (order by (select null)) as postal_id, 
    city, 
    state_id as region_id,
    state_name as region_name,
    lpad(cast(zip as string), 5, '0') as postal_code,
    lat as latitude, 
    lng as longitude,
    current_timestamp() as valid_from,
    '9999-12-31' as valid_to,
    true as is_current
from {{ source('reference_data', 'uszips') }}

{% if is_incremental() %}
    where region_id and zip not in (select region_id, zip from {{this}})
{% endif %}
