with date_dim as (
    select date_id, date from {{ ref('date_dim') }}
),

samples_received as (
    select 
        created_date_id,
        count(distinct trf_barcode) as orders_received,
        count(distinct(case when octave_status_id in (3, 5) then trf_barcode end)) as orders_on_hold
    from
        {{ ref('request_fact') }}
    where 
        request_category = "commercial"
    group by
        created_date_id
),

reports_delivered as (
    select
        released_date_id,
        count(distinct trf_barcode) as reports_delivered
    from
        {{ ref('request_fact') }}
    where
        octave_status_id = 7 -- 7 -> "Report Sent"
        and request_category = "commercial"
    group by
        released_date_id
),

processing_samples as (
    select
        created_date,
        count(distinct trf_barcode) as samples_in_process
    from (
        select 
            date(created_date) as created_date,
            sample_id,
            trf_barcode,
            request_id,
            sample_type_id,
            sample_status,
            classification
        from 
            {{ ref('stg_lims__s_sample') }}
        where 
            sample_status = "Processing"
    )
    group by
        created_date
),

incoming_and_bulk_kits as (
    select
        valid_from,
        count(distinct outgoing_kit_id) as incoming_kits,
        count(distinct(case when tube_serial_number is null then outgoing_kit_id end)) as bulk_kits
    from (
        select
            shipping_date_vendor_to_octave,
            valid_from,
            outgoing_kit_id,
            order_number,
            kit_item,
            kit_serial_number,
            kit_lot_number,
            tube_serial_number
        from 
            {{ ref('stg_lims__u_outgoingkit') }}
        where 
            kit_status in ("Picked up", "In transit", "On the way")
            
    )
    group by
        valid_from
)

select
    date,
    orders_received,
    reports_delivered,
    samples_in_process,
    orders_on_hold,
    incoming_kits,
    bulk_kits

from
    date_dim

left join samples_received
    on date_dim.date_id = samples_received.created_date_id

left join reports_delivered
    on date_dim.date_id = reports_delivered.released_date_id

left join processing_samples
    on date_dim.date = date(processing_samples.created_date)

left join incoming_and_bulk_kits
    on date_dim.date = date(incoming_and_bulk_kits.valid_from)

where 
    -- 24th March 2022 is the cutoff date for LIMS
    date_id >= "22083" and date <= date_add(current_date(), 3) 

order by 
    date_id desc;