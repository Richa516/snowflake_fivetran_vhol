with order_types as (
    select 
        distinct order_type as order_type 
    from 
        {{ ref('inter_salesforce__order') }}
    where
        order_type is not null
)

select
    -- dense_rank() over (order by order_type asc) as order_type_id,
    row_number() over (order by (select null)) as order_type_id,
    order_type
from
    order_types