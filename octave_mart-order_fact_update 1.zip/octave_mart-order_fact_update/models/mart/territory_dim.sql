{{
    config(
        materialized = 'incremental'
    )
}}

with territory_alignment_data as (
    select 
        territory_id as territory_key,
        territory_state,
        state_abbreviation,
        region,
        is_deleted,
        -- source,
        created_at as valid_from,
        last_modified_at,
        cast('9999-12-31' as timestamp) as valid_to
    from {{ ref('stg_salesforce__territory_alignments') }}
),

handling_nulls as (
    select 
        row_number() over (order by (select null)) as territory_id,
        territory_key,
        ifnull(territory_state,'N/A') as territory_state,
        ifnull(state_abbreviation,'N/A') as state_abbreviation,
        ifnull(region,'N/A') as region,
        is_deleted,
        -- source,
        valid_from,
        last_modified_at,
        valid_to
    from territory_alignment_data
)

select 
    territory_id,
    territory_key,
    territory_state,
    state_abbreviation,
    region,
    is_deleted,
    -- source,
    valid_from,
    last_modified_at,
    valid_to
from handling_nulls

{% if is_incremental() %}

    where territory_key not in (select territory_key from {{this}})

{% endif %}