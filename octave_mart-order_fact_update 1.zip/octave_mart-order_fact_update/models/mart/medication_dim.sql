with distinct_dmt_names as (
    select 
        distinct medication_name
    from 
        {{ ref('medication_dosage_dim') }}
)

select
    row_number() over (order by medication_name asc) as medication_id,
    medication_name
from
    distinct_dmt_names