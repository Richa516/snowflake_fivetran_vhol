{{ config(materialized = "incremental") }}


select 
    medication_dosage_id,
    medication_key,
    medication_code,
    medication_name,
    dosage_form,
    is_custom_medication,
    is_strict_adherence,
    dosage_unit,
    dosage_value,
    dosage_application,
    physicial_application,
    body_site_application,
    medication_freqency,
    medication_repeat_period,
    period_unit,
    valid_from,
    valid_to,
    is_current
from 
    {{ ref('stg_corehub_mart__medication') }}

{% if is_incremental() %}
    where medication_key not in (select medication_key from {{this}})
{% endif %}
