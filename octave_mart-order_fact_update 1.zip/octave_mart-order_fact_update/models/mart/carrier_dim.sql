with raw_data as (
    select 
        split_part(shipping_method, ' ', 1) as carrier,
        valid_from
    from {{ ref('stg_lims__u_outgoingkit') }}
),

initial_records as (
    select 
        carrier,
        min(valid_from) as valid_from
    from raw_data
    group by 1
),

handling_nulls as (
    select 
        row_number() over(order by valid_from) as carrier_id,
        ifnull(carrier,'N/A') as carrier,
        valid_from,
        cast('9999-12-31' as timestamp) as valid_to
    from initial_records
)

select 
    carrier_id,
    carrier,
    valid_from,
    valid_to
from handling_nulls