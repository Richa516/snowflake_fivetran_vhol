{{ config(materialized = "incremental") }}

select
    row_number() over (order by (select null)) as study_id, 
    study_title,
    company,
    pharmaceutical_agent,
    octave_solution_involved,
    status,
    current_timestamp() as valid_from,
    '9999-12-31' as valid_to,
    true as is_current
from {{ ref('clinical_studies') }}

{% if is_incremental() %}
    where study_title not in (select study_title from {{this}})
{% endif %}
