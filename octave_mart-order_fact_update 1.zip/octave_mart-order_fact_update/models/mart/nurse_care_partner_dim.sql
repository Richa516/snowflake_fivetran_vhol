select distinct 
    row_number() over (order by (select null)) as nurse_care_partner_id,
     _id as nurse_care_key, customdata.biography, 
     gender, 
     role.coding.code[0] as provider_specialty, 
     role.coding.display[0] as provider_type 
from hive_metastore.corehub_mart.practitioner 
where _id in ('650db485d988a6733849ab25', '645052aaef0598080f106c34') 
