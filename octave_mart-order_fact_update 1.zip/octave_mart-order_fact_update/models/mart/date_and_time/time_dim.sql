WITH time_dimension AS (
    SELECT
        CAST(FORMAT_STRING('%02d%02d%02d', hour, minute, second) AS INT) AS time_id,  -- Numeric TimeKey in HHMMSS format
        FORMAT_STRING('%02d:%02d:%02d', hour, minute, second) AS time,
        hour,
        minute,
        second,
        IF(hour < 12, 'AM', 'PM') AS am_pm,
        (hour * 3600 + minute * 60 + second) AS time_in_seconds,
        CASE
            WHEN hour < 4 THEN 'Midnight'
            WHEN hour < 12 THEN 'Morning'
            WHEN hour < 17 THEN 'Afternoon'
            WHEN hour < 21 THEN 'Evening'
            ELSE 'Night'
        END AS period_of_day
    FROM (
        SELECT EXPLODE(SEQUENCE(0, 23)) AS hour
    ) AS hours
    CROSS JOIN (
        SELECT EXPLODE(SEQUENCE(0, 59)) AS minute
    ) AS minutes
    CROSS JOIN (
        SELECT EXPLODE(SEQUENCE(0, 59)) AS second
    ) AS seconds
)
SELECT * FROM time_dimension;
