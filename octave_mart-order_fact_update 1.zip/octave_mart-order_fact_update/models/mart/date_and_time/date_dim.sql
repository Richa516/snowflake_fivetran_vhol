WITH date_series AS (
    SELECT date_seq AS date
    FROM (
        SELECT EXPLODE(SEQUENCE(
            TO_DATE('{{ var("start_date", "2020-01-01") }}'), 
            TO_DATE('{{ var("end_date", "2032-12-31") }}'), 
            INTERVAL 1 DAY
        )) AS date_seq
    )
), ranked_dates AS (
    SELECT
        date,
        DATE_FORMAT(date, 'EEEE') AS day_name,
        ROW_NUMBER() OVER (PARTITION BY YEAR(date), MONTH(date), DAYOFWEEK(date) ORDER BY date) AS day_of_week_in_month,
        ROW_NUMBER() OVER (PARTITION BY YEAR(date), DAYOFWEEK(date) ORDER BY date) AS day_of_week_in_year,
        ROW_NUMBER() OVER (PARTITION BY YEAR(date), QUARTER(date) ORDER BY date) AS day_of_quarter,
        WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'MM')) + 1 AS week_of_month,
        CASE 
            WHEN WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'MM')) + 1 = 1 THEN '1st'
            WHEN WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'MM')) + 1 = 2 THEN '2nd'
            WHEN WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'MM')) + 1 = 3 THEN '3rd'
            ELSE CONCAT(CAST(WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'MM')) + 1 AS STRING), 'th')
        END AS week_of_month_name,
        WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'quarter')) + 1 AS week_of_quarter,
        CASE 
            WHEN WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'quarter')) + 1 = 1 THEN '1st'
            WHEN WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'quarter')) + 1 = 2 THEN '2nd'
            WHEN WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'quarter')) + 1 = 3 THEN '3rd'
            ELSE CONCAT(CAST(WEEKOFYEAR(date) - WEEKOFYEAR(TRUNC(date, 'quarter')) + 1 AS STRING), 'th')
        END AS week_of_quarter_name,
        MONTH(date) - (QUARTER(date) - 1) * 3 AS month_of_quarter,
        CASE 
            WHEN MONTH(date) - (QUARTER(date) - 1) * 3 = 1 THEN '1st'
            WHEN MONTH(date) - (QUARTER(date) - 1) * 3 = 2 THEN '2nd'
            WHEN MONTH(date) - (QUARTER(date) - 1) * 3 = 3 THEN '3rd'
            ELSE CONCAT(CAST((MONTH(date) - (QUARTER(date) - 1) * 3) AS STRING), 'th')
        END AS month_of_quarter_name,
        TRUNC(date, 'quarter') AS FirstDayOfQuarter,
        LAST_DAY(ADD_MONTHS(TRUNC(date, 'quarter'), 3) - INTERVAL 1 DAY) AS LastDayOfQuarter,
        TRUNC(date, 'year') AS FirstDayOfYear,
        LAST_DAY(ADD_MONTHS(TRUNC(date, 'year'), 12) - INTERVAL 1 DAY) AS LastDayOfYear
    FROM date_series
)

SELECT
    CAST(CONCAT(SUBSTRING(CAST(YEAR(date) AS STRING), 3, 2), LPAD(DAYOFYEAR(date), 3, '0')) AS INT) AS date_id, -- Numeric Julian key
    date AS date,
    DATE_FORMAT(date, 'yyyy-MM-dd') AS full_date, -- ISO 8601 format
    DATE_FORMAT(date, 'dd') AS day_of_month,
    CASE 
        WHEN DAY(date) IN (11, 12, 13) THEN CONCAT(DATE_FORMAT(date, 'd'), 'th')
        ELSE CONCAT(DATE_FORMAT(date, 'd'), CASE DATE_FORMAT(date, 'd') 
                                                WHEN '1' THEN 'st'
                                                WHEN '2' THEN 'nd'
                                                WHEN '3' THEN 'rd'
                                                ELSE 'th' 
                                            END)
    END AS day_suffix,
    DATE_FORMAT(date, 'EEEE') AS day_name,
    CAST(EXTRACT(DAYOFWEEK FROM date) AS INT) AS day_of_week,
    day_of_week_in_month AS day_of_week_in_month,
    CONCAT(
        CASE 
            WHEN day_of_week_in_month = 1 THEN '1st'
            WHEN day_of_week_in_month = 2 THEN '2nd'
            WHEN day_of_week_in_month = 3 THEN '3rd'
            ELSE CONCAT(CAST(day_of_week_in_month AS STRING), 'th')
        END,
        ' ',
        DATE_FORMAT(date, 'EEEE')
    ) AS day_of_week_in_month_name,
    day_of_week_in_year AS day_of_week_in_year,
    CONCAT(
        CASE 
            WHEN day_of_week_in_year = 1 THEN '1st'
            WHEN day_of_week_in_year = 2 THEN '2nd'
            WHEN day_of_week_in_year = 3 THEN '3rd'
            ELSE CONCAT(CAST(day_of_week_in_year AS STRING), 'th')
        END,
        ' ',
        DATE_FORMAT(date, 'EEEE')
    ) AS day_of_week_in_year_name,
    day_of_quarter AS day_of_quarter,
    CONCAT(
        CASE 
            WHEN day_of_quarter = 1 THEN '1st'
            WHEN day_of_quarter = 2 THEN '2nd'
            WHEN day_of_quarter = 3 THEN '3rd'
            ELSE CONCAT(CAST(day_of_quarter AS STRING), 'th')
        END,
        ' day of the quarter'
    ) AS day_of_quarter_name,
    DAYOFYEAR(date) AS day_of_year,
    week_of_month AS week_of_month,
    week_of_month_name AS week_of_month_name,
    week_of_quarter AS week_of_quarter,
    week_of_quarter_name AS week_of_quarter_name,
    month_of_quarter AS month_of_quarter,
    month_of_quarter_name AS month_of_quarter_name,
    CAST(MONTH(date) AS STRING) AS month,
    DATE_FORMAT(date, 'MMMM') AS month_name,
    CAST(QUARTER(date) AS STRING) AS quarter,
    CONCAT('Q', QUARTER(date)) AS quarter_name,
    YEAR(date) AS year,
    CONCAT('CY ', YEAR(date)) AS year_name,
    CONCAT(DATE_FORMAT(date, 'MMM-yyyy')) AS month_year,
    CONCAT(LPAD(CAST(MONTH(date) AS STRING), 2, '0'), YEAR(date)) AS mmyyyy,
    TRUNC(date, 'MM') AS first_day_of_month,
    LAST_DAY(date) AS last_day_of_month,
    TRUNC(date, 'quarter') AS first_day_of_quarter,
    LAST_DAY(ADD_MONTHS(TRUNC(date, 'quarter'), 3) - INTERVAL 1 DAY) AS last_day_of_quarter,
    TRUNC(date, 'year') AS first_day_of_year,
    LAST_DAY(ADD_MONTHS(TRUNC(date, 'year'), 12) - INTERVAL 1 DAY) AS last_day_of_year,
    CASE WHEN DAYOFWEEK(date) BETWEEN 2 AND 6 THEN 1 ELSE 0 END AS is_weekday
FROM ranked_dates