{{ config(materialized = "incremental") }}

with
    most_recent_lims_subject as (select * from {{ ref("stg_lims__s_subject") }}),
    subject_table as (
        select
            row_number() over (order by (select null)) as subject_id, -- The order by (select null) ensures that the row numbers are assigned without any specific ordering
            -- {{ dbt_utils.generate_surrogate_key(['s_subjectid']) }} as octave_mart_subject_id, --keeping it safe here in case we en up using
            s_subjectid as subject_key,
            coalesce(cdx_clientid, -1) as client_id,
            coalesce(u_octaveid, -1) as octave_id,
            coalesce(u_alternateidentifier, -1) as alternate_id,
            coalesce(u_externalparticipantid, -1) as external_participant_id,
            coalesce(u_participantid, -1) as participant_id,
            coalesce(subjectdesc, 'N/A') as subject_description,
            birthdt as date_of_birth,
            genderflag as gender_flag,
            activeflag as patient_active_flag,
            moddt as lims_updated_record_date,
            coalesce(deathdt, 'N/A') as date_of_death,
            coalesce(u_ageatdiagnosis, 'N/A') as age_at_diagnosis,
            coalesce(u_height, 'N/A') as height,
            coalesce(u_weight, 'N/A') as weight,
            coalesce(u_smokingstatus, 'N/A') as smoking_status,
            coalesce(u_ethnicity, 'N/A') as ethnicity,
            coalesce(u_race, 'N/A') as race,
            current_timestamp() as valid_from,
            '9999-12-31' as valid_to,
            true as is_current
        from most_recent_lims_subject
    )
select *
from subject_table


{% if is_incremental() %}
    where subject_key not in (select subject_key from {{this}})
{% endif %}
