{{ config(materialized = "incremental") }}

with appointment_data as (
    select 
        distinct appointmenttype.coding[0].code as appointment_type,
        min(timestamp(_createdon)) as created_at
    from {{ source('corehub', 'appointment') }}
    group by 1
    order by 1
),

split_column as (
    select
        appointment_type,
        initcap(split_part(appointment_type, '_', 1)) as first_column,
        lower(split_part(appointment_type, '_', 2)) as second_column,
        lower(split_part(appointment_type, '_', 3)) as third_column,
        lower(split_part(appointment_type, '_', 4)) as fourth_column,
        created_at
    from appointment_data
),

readable_format as (
    select 
        concat(first_column, ' ', second_column, ' ', third_column, ' ', fourth_column) as appointment_type,
        created_at
    from split_column
),

handling_nulls as(
    select 
        row_number() over (order by (select null)) as appointment_id,
        ifnull(appointment_type, 'N/A') as appointment_type,
        current_timestamp() as valid_from,
        cast('9999-12-31' as timestamp) as valid_to
    from readable_format
)

select 
    appointment_id,
    appointment_type,
    valid_from,
    valid_to
from handling_nulls

{% if is_incremental() %}
 
    where appointment_type not in (select appointment_type from {{this}})
 
{% endif %}