select 
    patient_activity_id,
    patient_activity_type,
    activity_description
from {{ ref('seed_patient_activities') }}