-- Coming from a seed file
-- Seed file loaded to schema -> reference_data

select 
    status_id,
    status,
    type 
from 
    {{ source('reference_data', 'status_dim') }};