-- salesforce.order had some missing request_id. we fetched this request id from lims based on the trf id. Hence, salesforce.order is fixed.
-- Now we look at the oldest request in salesforce.order -> R-20220324-00001. This means that salesforce came into effect after 24th March 2022
-- Hence, in lims.s_request, we only keep records that are after the above date
-- Even after this, we have 72 trfs in lims that are not in salesforce. 
-- CA1CNNC4, 
-- CAXBKPEN is present in salesforce.order but not in lims.s_request. This particular trf is available in lims.u_outgoingkit. Ideally this should be available in lims.s_request also
-- Therefore LIMS should show 72 higher. These are the records that salesforce might not be tracking -> Study samples. However, Biogen samples are tracked by salesforce


{{ config(materialized = "incremental") }}

with medication_dim as (
    select  
        medication_id, 
        medication_name 
    from 
        {{ ref('medication_dim') }}
),

icd_codes as (
    select * from {{ source('reference_data', 'valid_icd_10_jan_24') }}
),

date_dim as (
    select 
        date_id, 
        date 
    from 
        {{ ref('date_dim') }}
),

time_dim as (
    select 
        time_id, 
        time 
    from 
        {{ ref('time_dim') }}
),

subject_dim as (
    select 
        distinct 
            subject_id, 
            subject_key 
    from 
        {{ ref('subject_dim') }}
),

requests as (
    select 
        * 
    from 
        {{ ref('stg_lims__s_request') }}
    where 
        lower(tube_barcode) not like "%dummy%" and lower(tube_barcode) not like "%test%"
        and request_id not in ('Submission', 'Routine Submission', 'Research Submission', 'Kit')
        and tube_barcode not in (   'LIMS_1790_T2', 'LIMS_1790', 'FRND32', 'FRND25', 'FRND21', 'FRND10', 'FRND09', 'FRND08', 'FRND07', 
                                    'FRND06', 'FRND05', 'FRND04', 'FRND03', 'FRND02', 'FRND01', 'VNV_TRF_06252022_3', 'VNV_TRF_06252022_2', 
                                'VNV_TRF_06252022_1', 'VNV_04302023_1', 'TRF-090523-1', 'OB3', 'OB2023FEB16', 'OB2023APR12', 'OB2', 'OB1')
        and request_id >= "R-20220324-00001"
),

samples as (
    select 
        sample_id, 
        request_id, 
        s_study_id, 
        sample_status 
    from 
        {{ ref('stg_lims__s_sample') }}
    where
        s_study_id = "CDX_Default"
        and sample_status != "Disposed"
        and storage_status != "In Circulation"
),

salesforce_orders as (
  select lims_request_id, trf_id from {{ ref('stg_salesforce__order') }}
),

octave_status_dim as (
    select * from {{ ref('status_dim') }} where type = "octave_order"
),

request_status_dim as (
    select * from {{ ref('status_dim') }} where type = "request"
),

fix_date_id as (
    select 
        row_number() over (order by requests.request_id asc) as request_id,
        
        created_date__date_dim.date_id as created_date_id,
        created_date__time_dim.time_id as created_time_id,
        
        ifnull(request_date__date_dim.date_id, -1) as request_date_id,
        ifnull(request_date__time_dim.time_id, -1) as request_time_id,
        
        modified_date__date_dim.date_id as modified_date_id,
        modified_date__time_dim.time_id as modified_time_id,
        
        ifnull(accepted_date__date_dim.date_id, -1) as accepted_date_id,
        ifnull(accepted_date__time_dim.time_id, -1) as accepted_time_id,
        
        ifnull(released_date__date_dim.date_id, -1) as released_date_id,
        ifnull(released_date__time_dim.time_id, -1) as released_time_id,
        
        due_date__date_dim.date_id as due_date_id,
        due_date__time_dim.time_id as due_time_id,
        
        ifnull(latest_report__date_dim.date_id, -1) as latest_report_date_id,
        ifnull(latest_report__time_dim.time_id, -1) as latest_report_time_id,
        
        -- ifnull(accession_date__date_dim.date_id, 'N/A') as accession_date_id,
        -- ifnull(accession_date__time_dim.time_id, 'N/A') as accession_time_id,
        
        ifnull(bill_complete, '-1') as bill_complete,
        ifnull(report_released_by, 'N/A') as report_released_by,
        ifnull(bill_release__date_dim.date_id, -1) as bill_release_date_id,
        ifnull(bill_release__time_dim.time_id, -1) as bill_release_time_id,
        
        ifnull(requests.request_id, 'N/A') as request_key,
        -- ifnull(sample_id, 'N/A') as sample_id,
        ifnull(priority, 'N/A') as priority,
        ifnull(subject_dim.subject_id, 'N/A') as subject_id,
        -- ifnull(dmt, 'N/A') as dmt,
        ifnull(medication_dim.medication_id, -1) as medication_id,
        
        ifnull(is_drawn_at_provider_location, '-1') as is_drawn_at_provider_location,
        ifnull(draw_location_note, 'N/A') as draw_location_note,
        ifnull(test_reason, 'N/A') as test_reason,
        ifnull(other_test_reason, 'N/A') as other_test_reason,
        
        ifnull(age_at_collection_date, -1) as age_at_collection_date,
        ifnull(test_name, 'N/A') as test_name,
        ifnull(icd_code_01, 'N/A') as icd_code_01,
        ifnull(icd_code_02, 'N/A') as icd_code_02,
        
        ifnull(trf_barcode, 'N/A') as trf_barcode,
        ifnull(sample_kit_id, 'N/A') as sample_kit_id,
        ifnull(outgoing_kit_id, 'N/A') as outgoing_kit_id,
        ifnull(tube_barcode, 'N/A') as tube_barcode,
        ifnull(sample_condition, 'N/A') as sample_condition,

        ifnull(physician_address_id, 'N/A') as physician_address_id,
        ifnull(notes, 'N/A') as notes,
        ifnull(study_id, -1) as study_id,
        -- ifnull(s_study_id, 'N/A') as s_study_id,
        ifnull(study_time_point, 'N/A') as study_time_point,

        ifnull(security_user, 'N/A') as security_user,
        ifnull(security_department, 'N/A') as security_department,
        
        -- ifnull(request_status, 'N/A') as request_status,
        ifnull(request_status_dim.status_id, -1) as request_status_id,

        -- ifnull(sample_status, 'N/A') as sample_status,
        -- ifnull(octave_status, 'N/A') as octave_status,
        ifnull(octave_status_dim.status_id, -1) as octave_status_id,
        -- ifnull(accession_user, 'N/A') as accession_user,
        
        source,
        case when lims_request_id is null then "study" else "commercial" end as request_category

    from 
        requests

    left join
        date_dim as created_date__date_dim
        on date(requests.created_date) = created_date__date_dim.date
    left join
        time_dim as created_date__time_dim
        on {{extract_time_from_datetime('requests', 'created_date')}} = created_date__time_dim.time

    left join
        date_dim as request_date__date_dim
        on date(requests.request_date) = request_date__date_dim.date
    left join
        time_dim as request_date__time_dim
        on {{extract_time_from_datetime('requests', 'request_date')}} = request_date__time_dim.time

    left join
        date_dim as modified_date__date_dim
        on date(requests.modified_date) = modified_date__date_dim.date
    left join
        time_dim as modified_date__time_dim
        on {{extract_time_from_datetime('requests', 'modified_date')}} = modified_date__time_dim.time

    left join
        date_dim as due_date__date_dim
        on date(requests.due_date) = due_date__date_dim.date
    left join
        time_dim as due_date__time_dim
        on {{extract_time_from_datetime('requests', 'due_date')}} = due_date__time_dim.time

    left join
        date_dim as accepted_date__date_dim
        on date(requests.accepted_date) = accepted_date__date_dim.date
    left join
        time_dim as accepted_date__time_dim
        on {{extract_time_from_datetime('requests', 'accepted_date') }} = accepted_date__time_dim.time

    left join
        date_dim as released_date__date_dim
        on date(requests.released_date) = released_date__date_dim.date
    left join
        time_dim as released_date__time_dim
        on {{extract_time_from_datetime('requests', 'released_date') }} = released_date__time_dim.time

    left join
        date_dim as bill_release__date_dim
        on date(requests.bill_released_date) = bill_release__date_dim.date
    left join
        time_dim as bill_release__time_dim
        on {{extract_time_from_datetime('requests', 'bill_released_date')}} = bill_release__time_dim.time

    left join
        date_dim as latest_report__date_dim
        on date(requests.latest_report_date) = latest_report__date_dim.date
    left join
        time_dim as latest_report__time_dim
        on {{extract_time_from_datetime('requests', 'latest_report_date')}} = latest_report__time_dim.time

    left join
        subject_dim
        on lower(trim(requests.subject_id)) = lower(trim(subject_dim.subject_key))

    left join
        medication_dim
        on lower(requests.dmt) = lower(medication_dim.medication_name)

    left join
        samples
        on requests.request_id = samples.request_id
    
    left join
        salesforce_orders
        on requests.request_id = salesforce_orders.lims_request_id
    
    left join
        octave_status_dim
        on requests.octave_status = octave_status_dim.status
    
    left join
        request_status_dim
        on requests.request_status = request_status_dim.status
)

select 
    request_id,
    request_key,

    created_date_id,
    created_time_id,
    request_date_id,
    request_time_id,
    modified_date_id,
    modified_time_id,
    accepted_date_id,
    accepted_time_id,
    released_date_id,
    released_time_id,
    due_date_id,
    due_time_id,
    latest_report_date_id,
    latest_report_time_id,

    -- request_key,
    priority,
    request_status_id,
    octave_status_id,
    
    subject_id,
    medication_id,

    bill_complete,
    report_released_by,
    bill_release_date_id,
    bill_release_time_id,
    
    physician_address_id,
    is_drawn_at_provider_location,
    draw_location_note,
    test_reason,
    other_test_reason,
    
    age_at_collection_date,
    test_name,
    icd_code_01,
    icd_code_02,
    
    trf_barcode,
    sample_kit_id,
    outgoing_kit_id,
    tube_barcode,
    sample_condition,

    notes,
    study_id,
    study_time_point,

    security_user,
    security_department,

    source,
    request_category

from 
    fix_date_id

{% if is_incremental() %}
    where
        created_date_id > (select max(created_date_id) from {{this}})
{% endif %}