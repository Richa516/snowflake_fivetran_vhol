{% test value_length(model, column_name, column_length) %}

    select *
    
    from {{ model }}

    where len({{ column_name }}) != {{ column_length }}

{% endtest %}