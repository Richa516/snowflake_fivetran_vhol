{% macro dedup_dataset(tablename, primarykey, datefield) %}

select 
    {{ tablename }}.*
from 
    {{ tablename }}
right join (
        select
            {{ primarykey }} as pk,
            max({{ datefield }}) as latestDate
        from
            {{ tablename }}
        group by
            {{ primarykey }}) as latestRecords
on 
    {{ tablename  }}.{{ primarykey }} = latestRecords.pk
    and {{ tablename }}.{{ datefield }} = latestRecords.latestDate

{% endmacro %}