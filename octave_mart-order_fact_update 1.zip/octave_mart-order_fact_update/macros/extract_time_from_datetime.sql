-- Intended use - To extract the time component from a datetime value. Ideal place to use is in a JOIN clause


{% macro extract_time_from_datetime(source, column_name) -%}

    date_format({{source}}.{{column_name}}, "HH:mm:ss")

{%- endmacro %}