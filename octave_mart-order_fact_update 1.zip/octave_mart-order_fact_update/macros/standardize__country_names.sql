{% macro standardize_country_name(column) %}
    
    replace(lower({{ column }}), " ")

{% endmacro %}