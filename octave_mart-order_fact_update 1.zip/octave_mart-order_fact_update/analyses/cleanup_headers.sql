-- Intended Use -> To clean up field names of massive datasets. Ideally suited for external tables
{% set column_names = dbt_utils.get_filtered_columns_in_relation(from = source('reference_data', 'pl_pfile_20050523_20240512')) %}
 
select
{%- for column in column_names %}
    `{{ column }}` as {{column | replace(" ", "_") | lower() | replace("(", "_") | replace(")", "_") | replace(".", "") | replace("-", "_") }} {% if not loop.last %},{% endif %}
{%- endfor %}
from
    {{ source('reference_data', 'pl_pfile_20050523_20240512') }}