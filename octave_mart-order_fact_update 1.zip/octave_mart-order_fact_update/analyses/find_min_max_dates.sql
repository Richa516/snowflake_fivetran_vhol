{# Intended Use - To get the minimum value from all the date fields in a dataset #}
{# Intended Application - To derive a cutoff date for reconciling numbers between different systems i.e., LIMS & Salesforce in our case #}

{%- set db_database = "octave_mart_dev" -%}
{%- set db_schema = "staging" -%}
{%- set db_table = "stg_lims__s_request" -%}

{%- set all_fields = adapter.get_columns_in_relation(api.Relation.create(database = db_database, schema = db_schema, identifier = db_table)) -%}
{%- set data_types = 'date', 'datetime', 'timestamp' -%}
{%- set required_fields = [] -%}

{%- for field in all_fields -%}
    {%- if field.data_type in data_types -%}
        {%- do required_fields.append(field.name) -%}
    {%- endif -%}
{%- endfor -%}

select
    {%- for required_field in required_fields %}
    min({{required_field}}) as min__{{required_field}},
    max({{required_field}}) as max__{{required_field}} {%- if not loop.last -%}, {%- endif -%}
    {%- endfor %}
from
    {{db_database}}.{{db_schema}}.{{db_table}}